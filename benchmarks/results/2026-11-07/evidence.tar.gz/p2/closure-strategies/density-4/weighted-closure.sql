-- Golden Scenario 03: Deep AST Expression Trees & Clause Minimization Stress

-- Focus: Recursive boolean/arithmetic expression simplification & intra-statement clause pruning

-- Target: expr_calc_inputs





































CREATE TABLE expr_calc_inputs (id INT PRIMARY KEY, base_val INT, factor_a INT, factor_b INT, flag_active BOOLEAN);
INSERT INTO expr_calc_inputs (id, base_val, factor_a, factor_b, flag_active) VALUES (1, 100.5000, 0, 5, 0), (2, 250.7500, 0, 0, 0);
CREATE VIEW study_v0 AS SELECT id, base_val FROM expr_calc_inputs;
CREATE VIEW study_v1 AS SELECT p0.id, p0.base_val FROM study_v0 p0;
CREATE VIEW study_v2 AS SELECT p0.id, p0.base_val FROM study_v1 p0 ;
CREATE VIEW study_v3 AS SELECT p0.id, p0.base_val FROM study_v2 p0 JOIN study_v1 p1 ON p1.id = p0.id JOIN study_v0 p2 ON p2.id = p0.id;
CREATE VIEW study_v4 AS SELECT p0.id, p0.base_val FROM study_v3 p0 JOIN study_v2 p1 ON p1.id = p0.id JOIN study_v1 p2 ON p2.id = p0.id JOIN study_v0 p3 ON p3.id = p0.id;
SELECT id, base_val FROM study_v4;
