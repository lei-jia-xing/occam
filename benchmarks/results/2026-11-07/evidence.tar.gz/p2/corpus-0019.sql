-- Golden Scenario 03: Deep AST Expression Trees & Clause Minimization Stress

-- Focus: Recursive boolean/arithmetic expression simplification & intra-statement clause pruning

-- Target: expr_calc_inputs





































CREATE TABLE expr_calc_inputs (id INT PRIMARY KEY, base_val NUMERIC(12,4), factor_a INT, factor_b INT, flag_active BOOLEAN);
INSERT INTO expr_calc_inputs (id, base_val, factor_a, factor_b, flag_active) VALUES (1, 100.5000, 10, 5, TRUE), (2, 250.7500, 20, 0, FALSE);
CREATE TABLE study_noise_0 (v INT);
INSERT INTO study_noise_0 VALUES (0);
INSERT INTO study_noise_0 VALUES (1);
INSERT INTO study_noise_0 VALUES (2);
INSERT INTO study_noise_0 VALUES (3);
INSERT INTO study_noise_0 VALUES (4);
INSERT INTO study_noise_0 VALUES (5);
SELECT id + 20, (base_val + 0) FROM expr_calc_inputs;
